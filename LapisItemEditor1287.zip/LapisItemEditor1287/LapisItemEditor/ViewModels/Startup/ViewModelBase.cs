using ReactiveUI;

namespace LapisItemEditor.ViewModels
{
    public class ViewModelBase : ReactiveObject
    {
    }
}