Sources available in:
https://github.com/hjnilsson/rme

Credits to hjnilsson (Remere) and Contributors:
https://github.com/hjnilsson/rme/graphs/contributors