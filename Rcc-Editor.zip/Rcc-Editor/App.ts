import Main from './src/Main';

Main.main();
